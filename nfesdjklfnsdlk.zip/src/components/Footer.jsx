import React from 'react'

const Footer = (props) => {
  return (
    <div>
      <h1>Tu record es {props.record}</h1>
    </div>
  )
}

export default Footer
