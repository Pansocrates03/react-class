import React from 'react'

const Parargaph = () => {
  return (
    <div>
      <p>Bienvenido al juego del botón: Hay dos botones, uno suma, el otro resta. En cada click el orden puede cambiar. Intenta obtener el número más alto.</p>
    </div>
  )
}

export default Parargaph
