import React, { Component } from 'react'

const Item = (props) => {
    return (
        <li>{props.item.accion}</li>
    )
}

export default Item
